import { Metadata } from 'next';
import Link from 'next/link';
import { PenTool, Image, Layout, Smartphone, Package, ArrowRight, CheckCircle2 } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Graphic Design & Creative Services',
  description: 'MetaZynx creates premium brand identities, high-converting ad creatives, social media assets, and landing page designs that stop the scroll and drive action. Design that performs.',
  keywords: 'graphic design agency India, ad creative design, brand identity design, social media design, landing page design, creative agency',
  alternates: { canonical: 'https://www.metazynx.com/services/design' },
};

export default function DesignPage() {
  const services = [
    { icon: Package, title: 'Brand Identity Design', description: 'Your brand is more than a logo — it\'s the complete visual language that communicates your values, personality, and promise to every audience that encounters you. We design comprehensive brand systems: logo, typography, colour palette, iconography, and brand guidelines that scale from business card to billboard without losing coherence.' },
    { icon: Image, title: 'High-Converting Ad Creatives', description: 'In a feed where users scroll 300 feet per day, your creative has 1.7 seconds to earn attention. We design ad creatives engineered with direct response principles — proven visual hierarchies, psychological triggers, and conversion-focused layouts — tested across thousands of campaigns to stop thumbs and drive clicks.' },
    { icon: Smartphone, title: 'Social Media Asset Design', description: 'A consistent, premium social presence builds brand equity with every post. We design monthly social media asset packages — feed posts, Stories, Reels covers, carousels — that maintain brand consistency across platforms while being optimised for each format\'s unique engagement mechanics.' },
    { icon: Layout, title: 'Landing Page UI/UX Design', description: 'Traffic is worthless without conversions. We design landing pages built around conversion rate optimisation principles — clear value propositions, friction-free user journeys, trust signals, and strategically placed CTAs. Every design decision is purposeful, testable, and tied to your conversion goals.' },
    { icon: PenTool, title: 'Presentation & Pitch Deck Design', description: 'Your presentations represent your brand in the moments that matter most — investor meetings, client pitches, internal leadership reviews. We design pitch decks and presentations that communicate authority, sophistication, and clarity through premium visual design.' },
    { icon: Image, title: 'Marketing Collateral', description: 'Brochures, product catalogues, email templates, infographics, and print materials — all designed with the same precision and brand consistency as your digital assets. Every touchpoint is an opportunity to reinforce your brand positioning.' },
  ];

  return (
    <main className="min-h-screen bg-[#FAFAF8] pt-24">

      <section className="bg-[#F2EFE9] min-h-[65vh] flex flex-col justify-center pt-16 pb-24 px-6 md:px-12 relative overflow-hidden border-b border-[#E0DDD6]">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#E8440A]/8 rounded-full blur-[120px] pointer-events-none" />
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-[13px] mb-6">[ Graphic Design & Creative ]</span>
          <h1 className="font-display font-extrabold text-[42px] md:text-[64px] text-[#0D0D0D] leading-[1.08] mb-6 max-w-4xl">
            Design That Stops the Scroll.<br/>
            Creative That Converts.
          </h1>
          <p className="font-sans font-light text-[18px] md:text-[21px] text-[#4A4A4A] max-w-[620px] leading-[1.65] mb-10">
            Great design isn't decoration — it's the difference between a brand that commands premium pricing and one that competes on price alone. MetaZynx creates visual identities and performance creatives that make ambitious brands impossible to ignore.
          </p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-[#E8440A] text-white font-sans font-bold text-[15px] px-8 py-4 rounded-md hover:bg-[#1B2D5B] transition-all duration-300 group">
            Start a Design Project <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>

      {/* Design services */}
      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Design Services ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1]">Every Creative Service Your Brand Needs</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-10 border border-[#E0DDD6] hover:border-[#E8440A]/40 hover:shadow-xl transition-all duration-300 group">
                  <div className="w-14 h-14 rounded-2xl bg-[#F2EFE9] flex items-center justify-center mb-6 group-hover:bg-[#E8440A]/10 transition-colors duration-300">
                    <Icon size={26} className="text-[#E8440A]" />
                  </div>
                  <h3 className="font-sans font-bold text-[22px] text-[#0D0D0D] mb-4 group-hover:text-[#E8440A] transition-colors">{s.title}</h3>
                  <p className="font-sans text-[16px] text-[#4A4A4A] leading-[1.75]">{s.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Design philosophy */}
      <section className="py-24 bg-[#0D0D0D] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Our Design Philosophy ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[48px] text-white tracking-tighter">Beauty Without Performance Is Decoration</h2>
            <p className="font-sans text-[17px] text-white/60 mt-4 max-w-2xl mx-auto leading-relaxed">Every design decision we make is tied to a measurable business outcome. We don't design to win awards. We design to win customers.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[['Strategy First', 'We understand your audience, competitors, and conversion goals before opening a single design file.'], ['Performance Tested', 'Our creatives are built to be A/B tested. We design multiple variants and let the data determine what wins.'], ['Brand Consistent', 'Every asset we produce reinforces your brand system — building cumulative recognition with every impression.']].map(([t, d], i) => (
              <div key={i} className="bg-white/5 rounded-2xl p-8 border border-white/10">
                <span className="font-sans font-black text-[48px] text-[#E8440A]/30 leading-none block mb-4">0{i+1}</span>
                <h3 className="font-sans font-bold text-[22px] text-white mb-3">{t}</h3>
                <p className="font-sans text-[15px] text-white/60 leading-relaxed">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-[#E8440A] text-center px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter mb-6">Your Brand Deserves Better Design.</h2>
          <p className="font-sans text-[18px] text-white/80 mb-10">Let's build a visual identity and creative system that makes your brand unmistakable.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-white text-[#E8440A] font-sans font-bold text-[16px] px-10 py-5 rounded-md hover:bg-[#0D0D0D] hover:text-white transition-all duration-300 group">
            Start Your Project <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </main>
  );
}
