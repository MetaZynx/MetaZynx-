import { Metadata } from 'next';
import Link from 'next/link';
import { Target, TrendingUp, BarChart2, Zap, RefreshCw, Users, ArrowRight, CheckCircle2 } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Meta & Google Ads Management',
  description: 'MetaZynx runs high-performance Meta and Google Ads campaigns engineered for maximum ROAS. Data-driven strategy, creative testing, audience targeting, and full-funnel optimisation. Stop burning budget. Start scaling.',
  keywords: 'Meta Ads agency, Google Ads management, Facebook advertising, performance marketing, paid social, PPC agency India, ROAS optimisation',
  alternates: { canonical: 'https://www.metazynx.com/services/ads' },
};

export default function AdsPage() {
  const services = [
    { icon: Target, title: 'Campaign Architecture & Strategy', description: 'Most ad accounts fail before a single rupee is spent — because the structure is wrong. We build campaigns from scratch with the right objective hierarchy, budget allocation, audience segmentation, and bidding strategy for your specific business model and goals.' },
    { icon: Users, title: 'Advanced Audience Targeting', description: 'We go far beyond basic interest targeting. Custom audiences, lookalike audiences, retargeting funnels, customer match lists, and behavioural segmentation — we find your ideal customer wherever they are on Meta and Google\'s networks.' },
    { icon: Zap, title: 'Creative Strategy & Production', description: 'The creative is 80% of campaign performance. Our team develops scroll-stopping ad creatives — static images, video ads, carousel formats, and dynamic ads — all designed with direct response principles that drive action, not just impressions.' },
    { icon: RefreshCw, title: 'Continuous A/B Testing', description: 'We never stop testing. Every element of your campaigns — headlines, visuals, CTAs, landing pages, audiences, bidding strategies — is systematically tested to identify winning combinations and eliminate underperformers before they drain budget.' },
    { icon: BarChart2, title: 'Conversion Tracking & Attribution', description: 'You can\'t optimise what you can\'t measure. We implement pixel-perfect tracking via Google Tag Manager, Meta Pixel, and GA4 — ensuring every conversion is attributed correctly and your campaigns are optimised against real business outcomes.' },
    { icon: TrendingUp, title: 'Scaling & Budget Optimisation', description: 'Finding a winning campaign is step one. Scaling it without destroying performance is the real skill. We scale winning ad sets with proven methodologies that preserve ROAS while increasing volume — turning a ₹1L/month winner into a ₹10L/month machine.' },
  ];

  const platforms = [
    { name: 'Meta Ads', desc: 'Facebook & Instagram advertising across Feed, Stories, Reels, and Messenger. Full-funnel campaigns from awareness to conversion.', color: '#1877F2' },
    { name: 'Google Ads', desc: 'Search, Display, Shopping, YouTube, and Performance Max campaigns. Capture demand at every stage of the buying journey.', color: '#4285F4' },
    { name: 'Google Shopping', desc: 'Dominate product search with optimised Shopping campaigns and feed management that drives qualified purchase intent traffic.', color: '#34A853' },
    { name: 'YouTube Ads', desc: 'In-stream and discovery video ads that build brand awareness and drive remarketing audiences at scale.', color: '#FF0000' },
  ];

  const faqs = [
    { q: 'What is a realistic ROAS expectation?', a: 'ROAS varies significantly by industry, product margins, and current account health. For e-commerce, we target a minimum of 3-4x ROAS in month one, scaling toward 6-8x by month three as we optimise. Service businesses measure cost-per-lead rather than ROAS, and we typically target a 40-60% reduction in CPL within the first 90 days.' },
    { q: 'How much ad spend do I need to get started?', a: 'We recommend a minimum monthly ad spend of ₹50,000 (approx $600) per platform to generate statistically significant data for optimisation. Lower budgets are possible but require longer timelines to see meaningful results.' },
    { q: 'Do you offer creative production as part of the service?', a: 'Yes. Our ads management service includes creative strategy and production. We develop all ad copy, static visuals, and can produce video ads. Exceptional creative is inseparable from campaign performance — we don\'t manage ads without controlling the creative.' },
    { q: 'How do you handle underperforming campaigns?', a: 'We diagnose the root cause before making changes — whether it\'s creative fatigue, audience saturation, landing page friction, or bid strategy. We present our analysis and recommended course of action with full transparency, and we never spend budget on campaigns we\'re not actively optimising.' },
  ];

  return (
    <main className="min-h-screen bg-[#FAFAF8] pt-24">

      {/* Hero */}
      <section className="bg-[#0D0D0D] min-h-[65vh] flex flex-col justify-center pt-16 pb-24 px-6 md:px-12 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, rgba(232,68,10,0.08) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-[#E8440A]/10 rounded-full blur-[150px] pointer-events-none" />
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-[13px] mb-6">[ Paid Advertising ]</span>
          <h1 className="text-white font-display font-extrabold text-[42px] md:text-[64px] leading-[1.08] mb-6 max-w-4xl">
            Stop Burning Budget.<br />
            Start Scaling Revenue.
          </h1>
          <p className="text-white/70 font-sans font-light text-[18px] md:text-[21px] max-w-[620px] leading-[1.65] mb-10">
            MetaZynx manages Meta and Google Ads campaigns that are engineered from the ground up to deliver maximum return on every rupee of ad spend — with the data, creative, and targeting precision to prove it.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/contact" className="inline-flex items-center gap-2 bg-[#E8440A] text-white font-sans font-bold text-[15px] px-8 py-4 rounded-md hover:bg-white hover:text-[#0D0D0D] transition-all duration-300 group">
              Get a Free Ads Audit <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      {/* Proof numbers */}
      <section className="py-16 bg-[#E8440A]">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[['8.4x', 'Average ROAS Delivered'], ['$6M+', 'Ad Spend Managed'], ['200+', 'Campaigns Launched'], ['40%', 'Avg CPL Reduction']].map(([v, l]) => (
            <div key={v}>
              <p className="font-sans font-black text-[44px] text-white leading-none mb-1 tracking-tighter">{v}</p>
              <p className="font-sans text-[12px] text-white/80 uppercase tracking-[2px]">{l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Platforms */}
      <section className="py-24 bg-[#F2EFE9] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Platforms We Master ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1]">Every Platform. One Team. Zero Gaps.</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {platforms.map((p, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6] hover:border-[#E8440A]/30 transition-all duration-300 hover:shadow-lg">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-3 h-3 rounded-full" style={{ background: p.color }} />
                  <h3 className="font-sans font-bold text-[22px] text-[#0D0D0D]">{p.name}</h3>
                </div>
                <p className="font-sans text-[16px] text-[#4A4A4A] leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ What We Do ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1]">The Complete Paid Advertising System</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6] hover:border-[#E8440A]/30 hover:shadow-lg transition-all duration-300 group">
                  <div className="w-12 h-12 rounded-xl bg-[#F2EFE9] flex items-center justify-center mb-6 group-hover:bg-[#E8440A]/10 transition-colors duration-300">
                    <Icon size={22} className="text-[#E8440A]" />
                  </div>
                  <h3 className="font-sans font-bold text-[20px] text-[#0D0D0D] mb-3 group-hover:text-[#E8440A] transition-colors">{s.title}</h3>
                  <p className="font-sans text-[15px] text-[#4A4A4A] leading-[1.7]">{s.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* What's included */}
      <section className="py-24 bg-[#1B2D5B] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Everything Included ]</span>
              <h2 className="font-sans font-bold text-[36px] md:text-[48px] text-white tracking-tighter leading-[1.1] mb-6">No Hidden Fees. No Surprises.</h2>
              <p className="font-sans text-[17px] text-white/70 leading-relaxed mb-8">Our ads management retainer includes everything you need to run high-performance campaigns — strategy, creative, optimisation, and reporting. No add-ons. No upsells.</p>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {['Full campaign setup and architecture', 'Monthly ad creative production', 'Weekly performance reviews', 'Conversion tracking implementation', 'Audience research and segmentation', 'Landing page recommendations', 'Monthly detailed reporting', 'Dedicated account manager access'].map((item, i) => (
                <div key={i} className="flex items-center gap-3 bg-white/5 rounded-xl px-5 py-4 border border-white/10">
                  <CheckCircle2 size={18} className="text-[#E8440A] shrink-0" />
                  <span className="font-sans text-[15px] text-white/80">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ FAQs ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[48px] text-[#0D0D0D] tracking-tighter">Paid Ads Questions Answered</h2>
          </div>
          <div className="space-y-6">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6]">
                <h3 className="font-sans font-bold text-[18px] text-[#0D0D0D] mb-3">{faq.q}</h3>
                <p className="font-sans text-[15px] text-[#4A4A4A] leading-[1.7]">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-[#E8440A] text-center px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter leading-[1.1] mb-6">Ready to Scale Your Ad Spend Profitably?</h2>
          <p className="font-sans text-[18px] text-white/80 mb-10 leading-relaxed">We'll audit your current campaigns and show you exactly where budget is being wasted and where the growth opportunities are.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-white text-[#E8440A] font-sans font-bold text-[16px] px-10 py-5 rounded-md hover:bg-[#0D0D0D] hover:text-white transition-all duration-300 group">
            Get Your Free Ads Audit <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </main>
  );
}
