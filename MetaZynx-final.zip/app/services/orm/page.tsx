import { Metadata } from 'next';
import Link from 'next/link';
import { ShieldCheck, Eye, Star, AlertCircle, TrendingUp, Search, ArrowRight } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Online Reputation Management (ORM) Services',
  description: 'MetaZynx protects and enhances your brand\'s online reputation. Proactive monitoring, review generation, crisis management, and search result suppression. Your reputation is your most valuable asset.',
  keywords: 'ORM agency India, online reputation management, review management, crisis PR, brand reputation, Google reputation management, negative review suppression',
  alternates: { canonical: 'https://www.metazynx.com/services/orm' },
};

export default function ORMPage() {
  const services = [
    { icon: Eye, title: 'Reputation Monitoring', description: '24/7 monitoring across Google, social platforms, review sites, news publications, and forums. We track every mention of your brand in real-time so you\'re never blindsided by negative content.' },
    { icon: Star, title: 'Review Generation & Management', description: 'A systematic strategy to generate authentic positive reviews on Google, Trustpilot, Glassdoor, and industry-specific platforms — while responding professionally to all reviews, positive and negative.' },
    { icon: AlertCircle, title: 'Crisis Communication Management', description: 'When things go wrong — and eventually they do for every brand — our crisis communication team responds with speed and precision. We protect brand equity, control the narrative, and guide you through recovery.' },
    { icon: Search, title: 'Search Result Suppression', description: 'Negative content appearing on page one of Google search results for your brand costs you clients every day. We engineer a content strategy that displaces negative results with authoritative, positive content over time.' },
    { icon: TrendingUp, title: 'Brand Building & Positive PR', description: 'The best defence is a strong offence. We proactively build your online brand presence — thought leadership content, media coverage, and social proof — that makes your reputation resilient to future attacks.' },
    { icon: ShieldCheck, title: 'Executive & Personal Brand ORM', description: 'For founders, executives, and public figures, personal reputation directly impacts business reputation. We manage and protect personal online presence for the leaders who represent your brand.' },
  ];

  return (
    <main className="min-h-screen bg-[#FAFAF8] pt-24">
      <section className="bg-[#1B2D5B] min-h-[65vh] flex flex-col justify-center pt-16 pb-24 px-6 md:px-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#E8440A]/8 rounded-full blur-[120px] pointer-events-none" />
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-[13px] mb-6">[ Online Reputation Management ]</span>
          <h1 className="text-white font-display font-extrabold text-[42px] md:text-[64px] leading-[1.08] mb-6 max-w-4xl">
            Protect What You've Built.<br/>Control Your Narrative.
          </h1>
          <p className="text-white/75 font-sans font-light text-[18px] md:text-[21px] max-w-[620px] leading-[1.65] mb-6">
            In today's world, your Google search results are your first impression for 90% of potential customers. A single negative review or news article on page one costs you clients you'll never even know you lost.
          </p>
          <p className="text-white/60 font-sans text-[17px] max-w-[600px] leading-relaxed mb-10">MetaZynx's ORM service takes a proactive, systematic approach to monitoring, protecting, and enhancing your brand's online reputation.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-[#E8440A] text-white font-sans font-bold text-[15px] px-8 py-4 rounded-md hover:bg-white hover:text-[#0D0D0D] transition-all duration-300 group">
            Get a Reputation Audit <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>

      <section className="py-16 bg-[#E8440A]">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[['90%', 'of consumers check reviews before buying'], ['86%', 'of people hesitate with a brand that has negative reviews'], ['4.2★', 'Minimum rating consumers expect'], ['1 page', 'Most users never go beyond Google page one']].map(([v, l]) => (
            <div key={v}><p className="font-sans font-black text-[36px] md:text-[44px] text-white leading-none mb-2 tracking-tighter">{v}</p><p className="font-sans text-[12px] text-white/80 tracking-wide">{l}</p></div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ ORM Services ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1]">Complete Reputation Protection & Growth</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6] hover:border-[#E8440A]/40 hover:shadow-lg transition-all duration-300 group">
                  <div className="w-12 h-12 rounded-xl bg-[#F2EFE9] flex items-center justify-center mb-6 group-hover:bg-[#E8440A]/10 transition-colors">
                    <Icon size={22} className="text-[#E8440A]" />
                  </div>
                  <h3 className="font-sans font-bold text-[20px] text-[#0D0D0D] mb-3 group-hover:text-[#E8440A] transition-colors">{s.title}</h3>
                  <p className="font-sans text-[15px] text-[#4A4A4A] leading-[1.7]">{s.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24 bg-[#E8440A] text-center px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter mb-6">Your Reputation Can't Wait.</h2>
          <p className="font-sans text-[18px] text-white/80 mb-10">Every day without ORM is another day your competitors can damage what you've built. Let's start protecting your brand today.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-white text-[#E8440A] font-sans font-bold text-[16px] px-10 py-5 rounded-md hover:bg-[#0D0D0D] hover:text-white transition-all duration-300 group">
            Get a Free Reputation Audit <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </main>
  );
}
