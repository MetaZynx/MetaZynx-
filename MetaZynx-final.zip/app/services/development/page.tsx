import { Metadata } from 'next';
import Link from 'next/link';
import { Code, Zap, ShieldCheck, Smartphone, TrendingUp, ArrowRight, CheckCircle2 } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Web Development Services',
  description: 'MetaZynx builds high-performance, conversion-optimised websites and web applications on Next.js, React, and modern tech stacks. Sub-second load times. Perfect Core Web Vitals. Built to rank and convert.',
  keywords: 'web development agency India, Next.js development, React development, e-commerce development, website optimisation, Core Web Vitals',
  alternates: { canonical: 'https://www.metazynx.com/services/development' },
};

export default function DevelopmentPage() {
  const services = [
    { icon: Code, title: 'Custom Web Application Development', description: 'Bespoke web applications built on Next.js, React, and TypeScript. We architect scalable, maintainable codebases that grow with your business — from early-stage MVPs to enterprise-grade platforms.' },
    { icon: Zap, title: 'Performance Optimisation', description: 'Page speed is a ranking factor, a conversion factor, and a revenue factor. We diagnose and resolve every Core Web Vitals issue — Largest Contentful Paint, Cumulative Layout Shift, Interaction to Next Paint — delivering sub-second load times that Google rewards and users love.' },
    { icon: TrendingUp, title: 'Conversion Rate Optimisation', description: 'More traffic means nothing if your website doesn\'t convert. We audit user journeys, identify friction points, redesign conversion paths, and implement A/B tests that systematically improve your conversion rate month after month.' },
    { icon: ShieldCheck, title: 'Security & Compliance', description: 'SSL certificates, GDPR compliance, security audits, and ongoing vulnerability monitoring. We build websites that protect your data and your users\' data — and keep them protected.' },
    { icon: Smartphone, title: 'Mobile-First Development', description: 'Over 60% of web traffic is mobile. We build genuinely mobile-first — not just responsive but architecturally designed for the mobile experience, with touch-optimised interfaces, mobile page speed, and mobile conversion paths.' },
    { icon: Code, title: 'E-Commerce Development', description: 'Shopify, custom Next.js storefronts, Razorpay and Stripe integration, inventory management, checkout optimisation — complete e-commerce solutions built for maximum conversion rate and scalability.' },
  ];

  const stack = ['Next.js 14+', 'React 18', 'TypeScript', 'Tailwind CSS', 'Vercel', 'Shopify', 'Supabase', 'PostgreSQL', 'Stripe', 'Razorpay', 'Framer Motion', 'Google Analytics 4'];

  return (
    <main className="min-h-screen bg-[#FAFAF8] pt-24">
      <section className="bg-[#0D0D0D] min-h-[65vh] flex flex-col justify-center pt-16 pb-24 px-6 md:px-12 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, rgba(27,45,91,0.4) 1px, transparent 1px)', backgroundSize: '28px 28px' }} />
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-[13px] mb-6">[ Web Development ]</span>
          <h1 className="text-white font-display font-extrabold text-[42px] md:text-[64px] leading-[1.08] mb-6 max-w-4xl">
            Built for Speed.<br/>Designed to Convert.
          </h1>
          <p className="text-white/70 font-sans font-light text-[18px] md:text-[21px] max-w-[620px] leading-[1.65] mb-10">
            Your website is your most important salesperson. MetaZynx builds high-performance web properties on modern tech stacks that load fast, rank high, and convert visitors into customers at every stage of the funnel.
          </p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-[#E8440A] text-white font-sans font-bold text-[15px] px-8 py-4 rounded-md hover:bg-white hover:text-[#0D0D0D] transition-all duration-300 group">
            Discuss Your Project <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>

      <section className="py-16 bg-[#1B2D5B]">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[['< 1s', 'Target Load Time'], ['100/100', 'Lighthouse Score'], ['99.9%', 'Uptime SLA'], ['0', 'Core Web Vitals Failures']].map(([v, l]) => (
            <div key={v}><p className="font-sans font-black text-[44px] text-[#E8440A] leading-none mb-2 tracking-tighter">{v}</p><p className="font-sans text-[12px] text-white/70 uppercase tracking-[2px]">{l}</p></div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Services ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1]">Web Development Services</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6] hover:border-[#E8440A]/40 hover:shadow-lg transition-all duration-300 group">
                  <div className="w-12 h-12 rounded-xl bg-[#F2EFE9] flex items-center justify-center mb-6 group-hover:bg-[#E8440A]/10 transition-colors">
                    <Icon size={22} className="text-[#E8440A]" />
                  </div>
                  <h3 className="font-sans font-bold text-[20px] text-[#0D0D0D] mb-3 group-hover:text-[#E8440A] transition-colors">{s.title}</h3>
                  <p className="font-sans text-[15px] text-[#4A4A4A] leading-[1.7]">{s.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24 bg-[#F2EFE9] border-y border-[#E0DDD6] px-6 md:px-12">
        <div className="max-w-7xl mx-auto text-center">
          <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Tech Stack ]</span>
          <h2 className="font-sans font-bold text-[36px] md:text-[48px] text-[#0D0D0D] tracking-tighter mb-12">Built on Modern Technology</h2>
          <div className="flex flex-wrap justify-center gap-3">
            {stack.map(tech => (
              <span key={tech} className="bg-white border border-[#E0DDD6] rounded-full px-5 py-2.5 font-sans font-medium text-[14px] text-[#0D0D0D] hover:border-[#E8440A] hover:text-[#E8440A] transition-colors cursor-default">{tech}</span>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-[#E8440A] text-center px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter mb-6">Ready to Build Something Exceptional?</h2>
          <p className="font-sans text-[18px] text-white/80 mb-10">Tell us about your project and we'll scope it, plan it, and build it to the highest standard.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-white text-[#E8440A] font-sans font-bold text-[16px] px-10 py-5 rounded-md hover:bg-[#0D0D0D] hover:text-white transition-all duration-300 group">
            Start Your Build <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </main>
  );
}
