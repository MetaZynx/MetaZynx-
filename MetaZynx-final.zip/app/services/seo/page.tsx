import { Metadata } from 'next';
import Link from 'next/link';
import { CheckCircle2, TrendingUp, Search, FileText, Link2, MapPin, BarChart2, ArrowRight, Star } from 'lucide-react';

export const metadata: Metadata = {
  title: 'SEO & Content Marketing Services',
  description: 'MetaZynx delivers enterprise-grade SEO and content marketing that compounds over time. Technical audits, keyword strategy, link building, and content that ranks and converts. Results in 90 days.',
  keywords: 'SEO agency India, content marketing, technical SEO, link building, local SEO, keyword strategy, organic traffic growth',
  alternates: { canonical: 'https://www.metazynx.com/services/seo' },
  openGraph: {
    title: 'SEO & Content Marketing | MetaZynx',
    description: 'Dominate search rankings with data-driven SEO that delivers compounding organic growth month after month.',
    url: 'https://www.metazynx.com/services/seo',
  },
};

export default function SEOPage() {
  const deliverables = [
    { icon: Search, title: 'Technical SEO Audit', description: 'We start by crawling your entire website to identify every technical barrier between you and page one — broken links, crawl errors, Core Web Vitals issues, duplicate content, and site architecture problems. Our audits go 12 layers deep, not three.' },
    { icon: FileText, title: 'Keyword Strategy & Mapping', description: 'Not all keywords are equal. We identify high-intent, commercially valuable search terms that your ideal customers are actually using — then map them precisely across every page of your website for maximum relevance and minimum cannibalisation.' },
    { icon: CheckCircle2, title: 'On-Page Optimisation', description: 'Title tags, meta descriptions, heading hierarchies, internal linking, image alt text, schema markup — every on-page element is optimised with the precision of a surgeon. We leave nothing unaddressed.' },
    { icon: Link2, title: 'Authority Link Building', description: 'Backlinks remain the single most powerful ranking signal. Our outreach-first link building strategy earns placements on genuinely authoritative, relevant domains — no link farms, no PBNs, no shortcuts that will penalise you in six months.' },
    { icon: FileText, title: 'Content Strategy & Creation', description: 'We research, plan, and produce content that ranks for competitive terms and converts visitors into customers. Every piece is built around search intent, optimised for featured snippets, and written to establish your brand as the definitive authority in your niche.' },
    { icon: MapPin, title: 'Local SEO & GBP Management', description: 'For businesses serving a geographic area, appearing in the Local Pack is non-negotiable. We optimise your Google Business Profile, build local citations, generate authentic reviews, and engineer your local digital presence for maximum visibility.' },
    { icon: BarChart2, title: 'Core Web Vitals & Technical Performance', description: 'Google\'s ranking algorithm explicitly factors in page experience. We diagnose and resolve Largest Contentful Paint, Cumulative Layout Shift, and First Input Delay issues that are suppressing your rankings and damaging user experience.' },
    { icon: TrendingUp, title: 'Transparent Monthly Reporting', description: 'Every month you receive a comprehensive performance report: keyword movements, organic traffic growth, backlinks earned, content published, and revenue attributed to organic search. No fluff. No vanity metrics. Just numbers that matter.' },
  ];

  const process = [
    { step: '01', title: 'Discovery & Audit', description: 'We analyse your website, competitors, and current search landscape to establish a clear baseline and identify the highest-impact opportunities.' },
    { step: '02', title: 'Strategy Development', description: 'We build a custom 12-month SEO roadmap — keyword targets, content calendar, link acquisition plan, and technical fix priority queue.' },
    { step: '03', title: 'Execution', description: 'Our SEO specialists implement technical fixes, publish optimised content, and execute link building outreach in parallel for compounding impact.' },
    { step: '04', title: 'Monitor & Scale', description: 'We track every ranking movement, analyse what\'s working, and double down on the strategies delivering the strongest results for your specific business.' },
  ];

  const faqs = [
    { q: 'How long does SEO take to show results?', a: 'For most websites, you can expect to see meaningful ranking improvements within 3-6 months. High-competition niches may take 9-12 months to reach page one for primary keywords. However, technical fixes and on-page optimisation often produce visible improvements within 4-8 weeks.' },
    { q: 'Do you use white-hat SEO techniques only?', a: 'Exclusively. Every strategy we deploy is aligned with Google\'s Webmaster Guidelines. We have never had a client penalised because we refuse to take shortcuts. We build sustainable, compounding organic growth — not short-term gains that collapse under algorithm updates.' },
    { q: 'What industries do you have SEO experience in?', a: 'E-commerce, SaaS, real estate, healthcare, education, finance, hospitality, D2C brands, and local service businesses. The fundamentals of SEO are universal, but our strategy adapts to the unique competitive dynamics of each sector.' },
    { q: 'How do you measure SEO success?', a: 'We measure what matters to your business: organic revenue, lead volume from organic traffic, keyword rankings for target terms, and organic visibility share. We never report on rankings alone — we tie every metric back to business outcomes.' },
  ];

  return (
    <main className="min-h-screen bg-[#FAFAF8] pt-24">

      {/* Hero */}
      <section className="bg-[#1B2D5B] min-h-[65vh] flex flex-col justify-center pt-16 pb-24 px-6 md:px-12 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.03) 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#E8440A]/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-[13px] mb-6">[ SEO & Content Marketing ]</span>
          <h1 className="text-white font-display font-extrabold text-[42px] md:text-[64px] leading-[1.08] mb-6 max-w-4xl">
            SEO That Compounds.<br />
            Content That Converts.
          </h1>
          <p className="text-white/75 font-sans font-light text-[18px] md:text-[21px] max-w-[620px] leading-[1.65] mb-10">
            While your competitors pay for every single visitor, MetaZynx engineers organic growth that compounds month after month — turning your website into an asset that generates leads while you sleep.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/contact" className="inline-flex items-center justify-center bg-[#E8440A] text-white font-sans font-bold text-[15px] px-8 py-4 rounded-md hover:bg-white hover:text-[#0D0D0D] transition-all duration-300 group gap-2">
              Get Your Free SEO Audit <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link href="/case-studies" className="inline-flex items-center justify-center bg-white/10 text-white font-sans font-medium text-[15px] px-8 py-4 rounded-md hover:bg-white/20 transition-all duration-300 border border-white/20">
              See Our Results
            </Link>
          </div>
        </div>
      </section>

      {/* Why SEO matters */}
      <section className="py-20 bg-[#F2EFE9] border-b border-[#E0DDD6]">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {[['68%', 'of all online experiences begin with a search engine'], ['0.63%', 'of Google users click on results from page two'], ['10x', 'higher conversion rate from organic vs paid traffic over time']].map(([stat, label]) => (
              <div key={stat} className="bg-white rounded-2xl p-8 border border-[#E0DDD6]">
                <p className="font-sans font-black text-[56px] text-[#E8440A] leading-none mb-3 tracking-tighter">{stat}</p>
                <p className="font-sans text-[16px] text-[#4A4A4A] leading-relaxed">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What We Deliver */}
      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Our SEO Services ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1] max-w-3xl mx-auto">
              Every Service You Need to Dominate Search
            </h2>
            <p className="font-sans text-[18px] text-[#4A4A4A] mt-4 max-w-2xl mx-auto leading-relaxed">
              Our SEO service isn't a single tactic — it's a complete growth system that addresses every factor Google uses to rank your website.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {deliverables.map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6] hover:border-[#E8440A]/40 hover:shadow-lg transition-all duration-300 group">
                  <div className="flex items-start gap-5">
                    <div className="w-12 h-12 rounded-xl bg-[#F2EFE9] flex items-center justify-center shrink-0 group-hover:bg-[#E8440A]/10 transition-colors duration-300">
                      <Icon size={22} className="text-[#E8440A]" />
                    </div>
                    <div>
                      <h3 className="font-sans font-bold text-[20px] text-[#0D0D0D] mb-3 group-hover:text-[#E8440A] transition-colors">{item.title}</h3>
                      <p className="font-sans text-[15px] text-[#4A4A4A] leading-[1.7]">{item.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-24 bg-[#0D0D0D] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Our Process ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter leading-[1.1]">How We Engineer Your Organic Growth</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {process.map((p, i) => (
              <div key={i} className="text-center group">
                <div className="w-20 h-20 rounded-2xl bg-[#E8440A]/10 border border-[#E8440A]/20 flex items-center justify-center mx-auto mb-6 group-hover:bg-[#E8440A]/20 transition-all duration-300">
                  <span className="font-sans font-black text-[28px] text-[#E8440A]">{p.step}</span>
                </div>
                <h3 className="font-sans font-bold text-[20px] text-white mb-3">{p.title}</h3>
                <p className="font-sans text-[15px] text-white/60 leading-relaxed">{p.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="py-20 bg-[#E8440A] px-6 md:px-12">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[['+312%', 'Average Traffic Growth'], ['90 Days', 'To First Results'], ['100%', 'White-Hat Methods'], ['24/7', 'Rank Monitoring']].map(([val, lbl]) => (
            <div key={val}>
              <p className="font-sans font-black text-[42px] md:text-[52px] text-white leading-none mb-2 tracking-tighter">{val}</p>
              <p className="font-sans text-[13px] text-white/80 uppercase tracking-[2px]">{lbl}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQs */}
      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ FAQs ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[48px] text-[#0D0D0D] tracking-tighter">Everything You Need to Know</h2>
          </div>
          <div className="space-y-6">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6]">
                <h3 className="font-sans font-bold text-[18px] text-[#0D0D0D] mb-3 flex items-start gap-3">
                  <Star size={18} className="text-[#E8440A] mt-1 shrink-0" />{faq.q}
                </h3>
                <p className="font-sans text-[15px] text-[#4A4A4A] leading-[1.7] pl-7">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-[#1B2D5B] text-center px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter leading-[1.1] mb-6">Ready to Own Page One?</h2>
          <p className="font-sans text-[18px] text-white/70 mb-10 max-w-xl mx-auto leading-relaxed">Get a comprehensive SEO audit of your website — completely free. We'll show you exactly what's holding you back and how to fix it.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-[#E8440A] text-white font-sans font-bold text-[16px] px-10 py-5 rounded-md hover:bg-white hover:text-[#0D0D0D] transition-all duration-300 group">
            Claim Your Free SEO Audit <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <p className="font-sans text-[13px] text-white/40 mt-4 uppercase tracking-[1px]">No contracts • No commitments • 100% actionable</p>
        </div>
      </section>
    </main>
  );
}
