import { Metadata } from 'next';
import Link from 'next/link';
import { Users, Video, BarChart2, Star, Heart, ArrowRight, CheckCircle2 } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Influencer Marketing & UGC Services',
  description: 'MetaZynx builds authentic influencer partnerships and UGC campaigns that drive real purchase intent. Creator sourcing, campaign management, content production, and measurable ROI. Real people. Real trust.',
  keywords: 'influencer marketing agency India, UGC marketing, creator partnerships, influencer campaign management, user generated content',
  alternates: { canonical: 'https://www.metazynx.com/services/influencer' },
};

export default function InfluencerPage() {
  const services = [
    { icon: Users, title: 'Creator Sourcing & Vetting', description: 'We identify creators whose audience genuinely matches your target customer — analysing engagement quality, audience demographics, past brand partnerships, and content authenticity. We never recommend a creator we wouldn\'t stand behind personally.' },
    { icon: Star, title: 'Campaign Strategy & Briefing', description: 'Great influencer content doesn\'t happen by accident. We develop comprehensive creative briefs that give creators everything they need to produce content that feels authentic to their audience while staying on-brand and on-message for your campaign.' },
    { icon: Video, title: 'UGC Production', description: 'User-generated content that works as paid ad creative is a highly specific format. We manage UGC creators who understand the balance between authentic feel and direct response performance — producing content that converts in Meta and Google ad placements.' },
    { icon: BarChart2, title: 'Campaign Management & Reporting', description: 'End-to-end campaign management from creator contracting and content approval to publishing, boosting, and performance tracking. We handle the operational complexity so you can focus on the results.' },
    { icon: Heart, title: 'Community Building', description: 'Beyond one-off campaigns, we help brands build ongoing creator communities — ambassador programmes, affiliate networks, and long-term partnerships that generate a continuous stream of authentic content and advocacy.' },
    { icon: Video, title: 'Paid Amplification', description: 'Organic influencer reach is the starting point. We boost the highest-performing creator content as paid social ads — giving winning content the media budget it deserves and multiplying your ROI.' },
  ];

  const tiers = [
    { name: 'Nano Creators', range: '1K–10K followers', why: 'Highest engagement rates (8-12%). Authentic audience trust. Perfect for niche targeting and UGC production.' },
    { name: 'Micro Creators', range: '10K–100K followers', why: 'Strong community connection. Category authority. Best balance of reach and engagement for most brands.' },
    { name: 'Macro Creators', range: '100K–1M followers', why: 'Significant reach at reasonable cost. Strong awareness and social proof signal for growing brands.' },
    { name: 'Mega / Celebrity', range: '1M+ followers', why: 'Maximum brand awareness impact. Best used for launches, repositioning, and cultural relevance campaigns.' },
  ];

  return (
    <main className="min-h-screen bg-[#FAFAF8] pt-24">
      <section className="bg-[#1B2D5B] min-h-[65vh] flex flex-col justify-center pt-16 pb-24 px-6 md:px-12 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(232,68,10,0.3) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(245,166,35,0.2) 0%, transparent 50%)' }} />
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-[13px] mb-6">[ Influencer & UGC Marketing ]</span>
          <h1 className="text-white font-display font-extrabold text-[42px] md:text-[64px] leading-[1.08] mb-6 max-w-4xl">
            Real People.<br/>Real Trust.<br/>Real Results.
          </h1>
          <p className="text-white/75 font-sans font-light text-[18px] md:text-[21px] max-w-[620px] leading-[1.65] mb-10">
            93% of consumers trust creator recommendations over brand advertising. MetaZynx builds influencer partnerships and UGC strategies that convert that trust into measurable revenue for your brand.
          </p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-[#E8440A] text-white font-sans font-bold text-[15px] px-8 py-4 rounded-md hover:bg-white hover:text-[#0D0D0D] transition-all duration-300 group">
            Build Your Creator Strategy <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>

      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Our Services ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1]">End-to-End Influencer Marketing</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6] hover:border-[#E8440A]/40 hover:shadow-lg transition-all duration-300 group">
                  <div className="w-12 h-12 rounded-xl bg-[#F2EFE9] flex items-center justify-center mb-6 group-hover:bg-[#E8440A]/10 transition-colors">
                    <Icon size={22} className="text-[#E8440A]" />
                  </div>
                  <h3 className="font-sans font-bold text-[20px] text-[#0D0D0D] mb-3 group-hover:text-[#E8440A] transition-colors">{s.title}</h3>
                  <p className="font-sans text-[15px] text-[#4A4A4A] leading-[1.7]">{s.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24 bg-[#F2EFE9] border-y border-[#E0DDD6] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Creator Tiers ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[48px] text-[#0D0D0D] tracking-tighter">The Right Creator for Every Goal</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {tiers.map((t, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 border border-[#E0DDD6] hover:border-[#E8440A]/30 transition-all duration-300">
                <div className="w-8 h-8 rounded-full bg-[#E8440A] flex items-center justify-center mb-4">
                  <span className="font-sans font-bold text-white text-[14px]">{i+1}</span>
                </div>
                <h3 className="font-sans font-bold text-[18px] text-[#0D0D0D] mb-1">{t.name}</h3>
                <p className="font-sans text-[13px] text-[#E8440A] font-medium mb-3">{t.range}</p>
                <p className="font-sans text-[14px] text-[#4A4A4A] leading-relaxed">{t.why}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-[#E8440A] text-center px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter mb-6">Ready to Harness Creator Power?</h2>
          <p className="font-sans text-[18px] text-white/80 mb-10">Let's build an influencer strategy that turns authentic voices into measurable revenue.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-white text-[#E8440A] font-sans font-bold text-[16px] px-10 py-5 rounded-md hover:bg-[#0D0D0D] hover:text-white transition-all duration-300 group">
            Plan Your Campaign <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </main>
  );
}
