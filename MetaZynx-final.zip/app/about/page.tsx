import { Metadata } from 'next';
import Link from 'next/link';
import { Linkedin, Target, Eye, Heart, Zap, TrendingUp, Users, Award, ArrowRight } from 'lucide-react';

export const metadata: Metadata = {
  title: 'About MetaZynx | Our Story, Mission & Team',
  description: 'MetaZynx was founded by Divyam Bajaj in 2022. Built on $100K+ in personal affiliate revenue and experience managing multi-billion dollar brand accounts. We exist to deliver real performance marketing results to ambitious brands.',
  keywords: 'about MetaZynx, Divyam Bajaj, MetaZynx founder, performance marketing agency story, digital marketing agency India',
  alternates: { canonical: 'https://www.metazynx.com/about' },
};

export default function AboutPage() {
  const values = [
    { icon: Target, title: 'Results Obsessed', description: 'We don\'t measure our success by hours worked or reports delivered. We measure it exclusively by the revenue growth, lead volume, and ROI we generate for the brands we partner with. Every decision we make is filtered through one question: does this move the needle?' },
    { icon: Eye, title: 'Radical Transparency', description: 'No hidden fees. No inflated metrics. No agency BS. Every report we send shows real numbers — what worked, what didn\'t, and exactly what we\'re doing about it. We believe that the brands who trust us deserve to know exactly where every rupee of their budget went and what it returned.' },
    { icon: Heart, title: 'Client First, Always', description: 'Your goals become our goals the moment you sign with us. We treat your budget with the same care we\'d give our own money — because we understand that behind every marketing budget is a founder\'s vision, an entrepreneur\'s risk, and a team\'s livelihood.' },
    { icon: Zap, title: 'Constantly Evolving', description: 'The digital marketing landscape in 2026 looks nothing like it did in 2022. Algorithm updates, AI disruption, platform policy changes, consumer behaviour shifts — we stay obsessively ahead of the curve so our clients never fall behind it.' },
  ];

  const milestones = [
    { year: '2022', title: 'MetaZynx Founded', description: 'Divyam Bajaj founded MetaZynx in April 2022 with a singular mission: deliver the kind of performance marketing results that only enterprise brands with eight-figure budgets had access to — for ambitious growth-stage businesses.' },
    { year: '2022', title: 'First Client Campaigns', description: 'Within the first quarter, MetaZynx launched its first paid advertising and SEO campaigns, establishing the data-driven methodology and transparent reporting approach that would define the agency\'s culture.' },
    { year: '2023', title: '360° Service Expansion', description: 'Responding to client demand for integrated marketing, MetaZynx expanded its service offering to include Graphic Design, Web Development, Influencer Marketing, and ORM — becoming a true 360° performance marketing agency.' },
    { year: '2024', title: 'Specialist Network Built', description: 'MetaZynx built a curated network of vetted specialists — senior media buyers, SEO experts, designers, and developers — enabling enterprise-grade execution across every channel without the overhead of a traditional agency.' },
    { year: 'Today', title: 'Building the Future', description: 'MetaZynx continues to grow its client portfolio and service capabilities, with a clear vision of becoming the most trusted performance marketing agency for ambitious brands across every industry.' },
  ];

  const stats = [
    { value: '$100K+', label: 'Founder\'s Personal Affiliate Revenue' },
    { value: '360°', label: 'Full-Service Marketing Capability' },
    { value: '90 Days', label: 'To Measurable Results' },
    { value: '0', label: 'Long-Term Contracts Required' },
  ];

  return (
    <main className="min-h-screen bg-[#FAFAF8] pt-24">

      {/* Hero */}
      <section className="bg-[#FAFAF8] min-h-[70vh] flex flex-col justify-center pt-16 pb-24 px-6 md:px-12 border-b border-[#E0DDD6] relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, rgba(27,45,91,0.04) 1px, transparent 1px)', backgroundSize: '36px 36px' }} />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#E8440A]/5 rounded-full blur-[150px] pointer-events-none" />
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <div className="max-w-4xl">
            <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-[13px] mb-6">[ Our Story ]</span>
            <h1 className="font-display font-extrabold text-[42px] md:text-[72px] text-[#0D0D0D] leading-[1.05] mb-8">
              We Were Tired of Agencies<br/>That Talk But Don't Deliver.
            </h1>
            <p className="font-sans text-[19px] md:text-[22px] text-[#4A4A4A] leading-[1.65] max-w-3xl mb-6">
              MetaZynx was built by a performance marketer who spent years watching agencies charge premium fees for mediocre results, hiding behind vanity metrics and complicated reports that obscured the simple truth: they weren't moving the needle.
            </p>
            <p className="font-sans text-[18px] text-[#4A4A4A] leading-[1.65] max-w-3xl">
              So we built the agency we always wished existed — one that leads with proof, operates with transparency, and measures success exclusively by the results it delivers.
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-[#1B2D5B]">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map(s => (
            <div key={s.value}>
              <p className="font-sans font-black text-[42px] md:text-[52px] text-[#E8440A] leading-none mb-2 tracking-tighter">{s.value}</p>
              <p className="font-sans text-[12px] text-white/70 uppercase tracking-[2px] leading-relaxed">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Founder section */}
      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            <div>
              <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ The Founder ]</span>
              <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter leading-[1.1] mb-8">Built by Someone Who's Actually Done It.</h2>
              <div className="flex items-start gap-6 mb-8">
                <div className="w-20 h-20 rounded-2xl bg-[#1B2D5B] flex items-center justify-center shrink-0">
                  <span className="font-sans font-black text-white text-[28px]">DB</span>
                </div>
                <div>
                  <h3 className="font-sans font-bold text-[24px] text-[#0D0D0D] mb-1">Divyam Bajaj</h3>
                  <p className="font-sans text-[14px] text-[#E8440A] font-bold uppercase tracking-[1px] mb-3">Founder & CEO, MetaZynx</p>
                  <a href="https://www.linkedin.com/in/divyambajaj333" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-[#1B2D5B] font-sans text-[14px] hover:text-[#E8440A] transition-colors">
                    <Linkedin size={16} /> linkedin.com/in/divyambajaj333
                  </a>
                </div>
              </div>
              <div className="space-y-5 text-[#4A4A4A] font-sans text-[17px] leading-[1.75]">
                <p>Before founding MetaZynx, Divyam Bajaj built over $100,000 in affiliate revenue as a solo operator — developing firsthand expertise in SEO, paid media, conversion optimisation, and digital growth systems that most agency founders have only read about in textbooks.</p>
                <p>He went on to manage marketing accounts for multi-billion dollar brands, overseeing Meta and Google Ads campaigns at a scale that gave him rare insight into what separates genuinely effective performance marketing from expensive activity that looks busy but delivers little.</p>
                <p>In 2022, he founded MetaZynx with a clear mandate: bring enterprise-grade performance marketing strategy and execution to ambitious growth-stage brands, without the enterprise price tag, the bloated account team, or the opacity that defines legacy agencies.</p>
                <p>Every strategy MetaZynx implements has been personally tested, refined, and proven by Divyam before it's deployed for a client. We never recommend anything we haven't validated ourselves.</p>
              </div>
            </div>
            <div className="space-y-6">
              <div className="bg-[#F2EFE9] rounded-2xl p-8 border border-[#E0DDD6]">
                <h3 className="font-sans font-bold text-[20px] text-[#0D0D0D] mb-6">Credentials & Experience</h3>
                {[
                  ['$100K+', 'Personal affiliate revenue generated as solo operator'],
                  ['Multi-billion', 'Dollar brand accounts managed at senior level'],
                  ['Meta & Google', 'Certified ads specialist with hands-on campaign experience'],
                  ['BBA', 'Business Administration, Chandigarh University'],
                  ['Founded 2022', 'MetaZynx established in April 2022, Chandigarh'],
                ].map(([label, desc]) => (
                  <div key={label} className="flex items-start gap-4 py-4 border-b border-[#E0DDD6] last:border-0">
                    <span className="font-sans font-bold text-[14px] text-[#E8440A] shrink-0 w-28">{label}</span>
                    <span className="font-sans text-[15px] text-[#4A4A4A] leading-relaxed">{desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-24 bg-[#0D0D0D] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Our Values ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter leading-[1.1]">The Principles That Guide Everything We Do</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {values.map((v, i) => {
              const Icon = v.icon;
              return (
                <div key={i} className="bg-white/5 rounded-2xl p-8 border border-white/10 hover:border-[#E8440A]/30 transition-all duration-300 group">
                  <div className="w-14 h-14 rounded-2xl bg-[#E8440A]/10 flex items-center justify-center mb-6 group-hover:bg-[#E8440A]/20 transition-colors">
                    <Icon size={26} className="text-[#E8440A]" />
                  </div>
                  <h3 className="font-sans font-bold text-[22px] text-white mb-4">{v.title}</h3>
                  <p className="font-sans text-[16px] text-white/60 leading-[1.75]">{v.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24 bg-[#FAFAF8] px-6 md:px-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ Our Journey ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter">The MetaZynx Story</h2>
          </div>
          <div className="relative">
            <div className="absolute left-[28px] top-0 bottom-0 w-[2px] bg-[#E0DDD6]" />
            <div className="space-y-10">
              {milestones.map((m, i) => (
                <div key={i} className="flex items-start gap-8 relative">
                  <div className="w-14 h-14 rounded-full bg-[#E8440A] flex items-center justify-center shrink-0 relative z-10 shadow-lg shadow-[#E8440A]/20">
                    <span className="font-sans font-black text-white text-[11px] text-center leading-tight px-1">{m.year}</span>
                  </div>
                  <div className="bg-white rounded-2xl p-8 border border-[#E0DDD6] flex-1 hover:border-[#E8440A]/30 hover:shadow-lg transition-all duration-300">
                    <h3 className="font-sans font-bold text-[20px] text-[#0D0D0D] mb-3">{m.title}</h3>
                    <p className="font-sans text-[16px] text-[#4A4A4A] leading-[1.7]">{m.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 bg-[#F2EFE9] border-y border-[#E0DDD6] px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-sans font-bold text-[13px] text-[#E8440A] uppercase tracking-[2px] mb-4 block">[ The Team ]</span>
            <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-[#0D0D0D] tracking-tighter">Senior Expertise. Lean Structure.</h2>
            <p className="font-sans text-[18px] text-[#4A4A4A] mt-4 max-w-2xl mx-auto leading-relaxed">MetaZynx operates with a founder-led model backed by a curated network of vetted specialists — giving clients senior-level strategy and execution without the overhead and account management layers of a traditional agency.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { initials: 'DB', bg: '#1B2D5B', name: 'Divyam Bajaj', role: 'Founder & CEO', desc: '$100K+ affiliate revenue. Multi-billion dollar brand experience. Your strategic lead on every engagement.', link: 'https://www.linkedin.com/in/divyambajaj333', linkLabel: 'LinkedIn Profile' },
              { initials: '◎', bg: '#E8440A', name: 'Specialist Partner Network', role: 'Delivery Team', desc: 'A curated network of vetted senior specialists — media buyers, SEO experts, designers, developers — executing with precision on every channel.', link: null, linkLabel: null },
              { initials: '+', bg: '#0D0D0D', name: 'Join Our Team', role: "We're Hiring", desc: "Results-obsessed performance marketers, designers, and developers. If you're exceptional at what you do, we want to talk.", link: 'mailto:info@metazynx.com?subject=Job Application', linkLabel: 'Send Application' },
            ].map((member, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 border border-[#E0DDD6] hover:border-[#E8440A]/30 hover:shadow-xl transition-all duration-300 group flex flex-col">
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 font-sans font-black text-white text-[24px]" style={{ background: member.bg }}>{member.initials}</div>
                <h3 className="font-sans font-bold text-[22px] text-[#0D0D0D] mb-1 group-hover:text-[#E8440A] transition-colors">{member.name}</h3>
                <p className="font-sans text-[13px] text-[#E8440A] font-bold uppercase tracking-[1px] mb-4">{member.role}</p>
                <p className="font-sans text-[15px] text-[#4A4A4A] leading-relaxed flex-grow mb-6">{member.desc}</p>
                {member.link && <a href={member.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 font-sans font-medium text-[14px] text-[#1B2D5B] hover:text-[#E8440A] transition-colors"><ArrowRight size={14} />{member.linkLabel}</a>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-[#E8440A] text-center px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-sans font-bold text-[36px] md:text-[52px] text-white tracking-tighter mb-6">Ready to Work With a Team That Delivers?</h2>
          <p className="font-sans text-[18px] text-white/80 mb-10">Book a free 360° marketing audit. No sales pitch — just an honest assessment of where your brand stands and exactly how we'd grow it.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 bg-white text-[#E8440A] font-sans font-bold text-[16px] px-10 py-5 rounded-md hover:bg-[#0D0D0D] hover:text-white transition-all duration-300 group">
            Book Your Free Audit <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </main>
  );
}
