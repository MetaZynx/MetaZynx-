import { Metadata } from 'next';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { CheckCircle2 } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Web Development | MetaZynx',
  description: 'High-performance, conversion-optimised websites and landing pages built on modern tech stacks for serious brands.',
  alternates: {
    canonical: 'https://www.metazynx.com/services/development',
  },
};

export default function DevelopmentPage() {
  const deliverables = [
    { title: 'Landing Page Development', description: 'High-converting, standalone pages designed for specific marketing campaigns.' },
    { title: 'Full Website Builds', description: 'Custom, scalable websites built to represent your brand and drive action.' },
    { title: 'Shopify & E-Commerce Stores', description: 'Optimized online stores designed to maximize sales and average order value.' },
    { title: 'Page Speed Optimisation', description: 'Technical improvements to ensure lightning-fast load times across all devices.' },
    { title: 'Conversion Rate Optimisation', description: 'Data-driven tweaks to your user experience to turn more visitors into buyers.' },
    { title: 'Ongoing Maintenance & Support', description: 'Reliable technical support to keep your site secure, updated, and running smoothly.' }
  ];

  const whyCards = [
    { title: 'Speed First', description: 'Sub-2 second load times as standard. Every millisecond of delay costs conversions.' },
    { title: 'Built to Convert', description: 'UX and copy are structured around your customer journey and conversion goals' },
    { title: 'Modern Tech Stack', description: 'Next.js, React, Shopify — built for performance and scalability' }
  ];

  const stats = [
    { value: '<2s', label: 'Average Load Time' },
    { value: '+40%', label: 'Average Conversion Lift' },
    { value: '100%', label: 'Mobile Optimised' }
  ];

  return (
    <main className="min-h-screen flex flex-col font-sans">
      <Navbar />
      
      {/* Section 1 — Hero */}
      <section className="w-full bg-[#1B2D5B] min-h-[60vh] flex flex-col justify-center pt-32 pb-20 px-6 md:px-12">
        <div className="max-w-7xl mx-auto w-full">
          <span className="block text-[#E8440A] uppercase tracking-[3px] font-sans font-bold text-sm mb-6">
            WEB DEVELOPMENT
          </span>
          <h1 className="text-white font-display font-extrabold text-[40px] md:text-[56px] leading-[1.1] mb-6">
            Websites Built to Convert
          </h1>
          <p className="text-white/75 font-sans font-light text-[18px] md:text-[20px] max-w-[600px] leading-[1.6] mb-10">
            High-performance, conversion-optimised websites and landing pages built on modern tech stacks for serious brands.
          </p>
          <Link 
            href="/contact"
            className="inline-flex items-center justify-center bg-[#E8440A] text-white font-sans font-bold text-[16px] px-8 py-4 rounded-md hover:scale-[1.03] transition-transform duration-200"
          >
            Get Your Free Audit →
          </Link>
        </div>
      </section>

      {/* Section 2 — What We Deliver */}
      <section className="w-full bg-[#FAFAF8] py-24 px-6 md:px-12">
        <div className="max-w-7xl mx-auto w-full">
          <h2 className="text-[#1B2D5B] font-display font-bold text-[36px] md:text-[48px] mb-16">
            What We Deliver
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
            {deliverables.map((item, i) => (
              <div key={i} className="flex items-start gap-4">
                <CheckCircle2 className="text-[#E8440A] shrink-0 mt-1" size={24} />
                <div>
                  <h3 className="text-[#1B2D5B] font-sans font-bold text-[20px] mb-2">{item.title}</h3>
                  <p className="text-[#1B2D5B]/70 font-sans text-[16px] leading-[1.6]">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 3 — Why MetaZynx */}
      <section className="w-full bg-white py-24 px-6 md:px-12">
        <div className="max-w-7xl mx-auto w-full">
          <h2 className="text-[#1B2D5B] font-display font-bold text-[36px] md:text-[48px] text-center mb-16">
            Why MetaZynx?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {whyCards.map((card, i) => (
              <div key={i} className="bg-white border border-[#1B2D5B] rounded-[12px] p-8 flex flex-col">
                <span className="text-[#E8440A] font-display font-bold text-[32px] mb-6">
                  0{i + 1}
                </span>
                <h3 className="text-[#1B2D5B] font-sans font-bold text-[22px] mb-4">
                  {card.title}
                </h3>
                <p className="text-[#1B2D5B]/80 font-sans text-[16px] leading-[1.6]">
                  {card.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 4 — Results Bar */}
      <section className="w-full bg-[#1B2D5B] py-20 px-6 md:px-12">
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            {stats.map((stat, i) => (
              <div key={i} className="flex flex-col items-center">
                <span className="text-[#E8440A] font-display font-extrabold text-[48px] md:text-[56px] leading-none mb-4">
                  {stat.value}
                </span>
                <span className="text-white font-sans font-light text-[14px] uppercase tracking-[2px]">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 5 — Bottom CTA */}
      <section className="w-full bg-[#FAFAF8] py-24 px-6 md:px-12 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-[#1B2D5B] font-display font-extrabold text-[40px] md:text-[56px] mb-6">
            Ready to Grow?
          </h2>
          <p className="text-[#1B2D5B]/70 font-sans font-light text-[18px] md:text-[20px] mb-10">
            Let&apos;s engineer a growth strategy tailored to your brand&apos;s unique goals.
          </p>
          <Link 
            href="/contact"
            className="inline-flex items-center justify-center bg-[#E8440A] text-white font-sans font-bold text-[16px] px-8 py-4 rounded-md hover:scale-[1.03] transition-transform duration-200"
          >
            Book Your Free Audit Today →
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}
