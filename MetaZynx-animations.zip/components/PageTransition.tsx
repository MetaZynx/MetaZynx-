'use client';

import { motion, AnimatePresence } from 'motion/react';
import { usePathname } from 'next/navigation';
import { ReactNode, useEffect, useState } from 'react';

export default function PageTransition({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [isFirstMount, setIsFirstMount] = useState(true);

  useEffect(() => {
    setIsFirstMount(false);
  }, []);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={pathname}
        initial={isFirstMount ? false : { opacity: 0, y: 16, filter: 'blur(4px)' }}
        animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
        exit={{ opacity: 0, y: -16, filter: 'blur(4px)' }}
        transition={{ duration: 0.45, ease: [0.33, 1, 0.68, 1] }}
      >
        {/* Page wipe overlay */}
        <motion.div
          className="fixed inset-0 z-[200] bg-[#E8440A] origin-bottom pointer-events-none"
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 0 }}
          exit={{ scaleY: [0, 1, 1, 0], originY: ['bottom', 'bottom', 'top', 'top'] }}
          transition={{ duration: 0.6, times: [0, 0.4, 0.5, 1], ease: 'easeInOut' }}
        />
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
