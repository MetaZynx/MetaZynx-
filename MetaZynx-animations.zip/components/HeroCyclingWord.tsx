'use client';

import { useState, useEffect, useRef } from 'react';

const words = ['Empires', 'Revenue', 'Results', 'Legacies'];
const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

export default function HeroCyclingWord() {
  const [index, setIndex] = useState(0);
  const [displayed, setDisplayed] = useState(words[0]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const scrambleTo = (target: string) => {
    let frame = 0;
    const totalFrames = target.length * 4;
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      frame++;
      const progress = frame / totalFrames;
      const revealed = Math.floor(progress * target.length);
      setDisplayed(
        target.split('').map((char, i) => {
          if (i < revealed) return char;
          return CHARS[Math.floor(Math.random() * CHARS.length)];
        }).join('')
      );
      if (frame >= totalFrames) {
        setDisplayed(target);
        if (intervalRef.current) clearInterval(intervalRef.current);
      }
    }, 35);
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex(prev => {
        const next = (prev + 1) % words.length;
        scrambleTo(words[next]);
        return next;
      });
    }, 2800);
    return () => { clearInterval(timer); if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  return (
    <span style={{ color: '#E8440A', fontFamily: 'monospace', letterSpacing: '-0.02em' }}>
      {displayed}
    </span>
  );
}
