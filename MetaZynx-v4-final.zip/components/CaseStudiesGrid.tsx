'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';

const caseStudies = [
  {
    id: 1,
    client: 'E-Commerce Brand',
    category: 'Paid Ads',
    industry: 'E-Commerce',
    title: '6.2x ROAS in 90 Days',
    challenge: 'High CPA and severe creative fatigue on Meta Ads were eating into profit margins.',
    metrics: [
      { label: 'ROAS', value: '6.2x' },
      { label: 'CPA', value: '-42%' }
    ],
    slug: 'ecommerce-6x-roas',
    image: ''
  },
  {
    id: 2,
    client: 'Real Estate Developer',
    category: 'Paid Ads',
    industry: 'Real Estate',
    title: '480% Increase in Qualified Leads',
    challenge: 'Generating high-volume but low-quality leads from generic search campaigns.',
    metrics: [
      { label: 'Lead Volume', value: '+480%' },
      { label: 'CPL', value: '-35%' }
    ],
    slug: 'real-estate-lead-generation',
    image: ''
  },
  {
    id: 3,
    client: 'B2B SaaS Platform',
    category: 'SEO',
    industry: 'SaaS',
    title: '215% Organic Traffic Growth',
    challenge: 'Stuck on page 2 for high-intent, bottom-of-funnel industry keywords.',
    metrics: [
      { label: 'Traffic', value: '+215%' },
      { label: 'Top 3 Ranks', value: '45+' }
    ],
    slug: 'saas-organic-traffic-growth',
    image: ''
  },
  {
    id: 4,
    client: 'Healthcare Provider',
    category: 'ORM',
    industry: 'Healthcare',
    title: 'Reputation Score from 3.1 to 4.8',
    challenge: 'Negative legacy reviews were severely impacting new patient acquisition.',
    metrics: [
      { label: 'Rating', value: '4.8/5' },
      { label: 'Reviews', value: '1,200+' }
    ],
    slug: 'healthcare-reputation-management',
    image: ''
  },
  {
    id: 5,
    client: 'D2C Retailer',
    category: 'Development',
    industry: 'Retail',
    title: 'Sub-2s Load Time & 40% Conv. Lift',
    challenge: 'A slow, bloated legacy Shopify theme was causing massive cart abandonment.',
    metrics: [
      { label: 'Load Time', value: '< 2s' },
      { label: 'Conv. Rate', value: '+40%' }
    ],
    slug: 'd2c-retailer-conversion-lift',
    image: ''
  },
  {
    id: 6,
    client: 'Luxury Resort',
    category: 'Social',
    industry: 'Hospitality',
    title: '3M+ Organic Views via Creators',
    challenge: 'Low brand awareness and engagement among the lucrative Gen-Z traveler demographic.',
    metrics: [
      { label: 'Views', value: '3M+' },
      { label: 'Engagement', value: '+310%' }
    ],
    slug: 'luxury-resort-creator-marketing',
    image: ''
  }
];

const categories = ['All', 'SEO', 'Paid Ads', 'Social', 'ORM', 'Development'];

export default function CaseStudiesGrid() {
  const [activeFilter, setActiveFilter] = useState('All');
  const [isLoading, setIsLoading] = useState(false);

  const handleFilterChange = (category: string) => {
    if (category === activeFilter) return;
    setIsLoading(true);
    setActiveFilter(category);
    
    // Simulate network/filtering delay
    setTimeout(() => {
      setIsLoading(false);
    }, 600);
  };

  const filteredStudies = activeFilter === 'All' 
    ? caseStudies 
    : caseStudies.filter(study => study.category === activeFilter);

  return (
    <section className="py-20 max-w-7xl mx-auto px-6 md:px-12 w-full">
      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-center gap-3 mb-16">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => handleFilterChange(category)}
            disabled={isLoading}
            className={`px-6 py-2.5 rounded-full font-sans font-bold text-[14px] uppercase tracking-[1px] transition-all duration-300 ${
              activeFilter === category
                ? 'bg-primary-text text-primary-bg shadow-md'
                : 'bg-secondary-bg text-secondary-text border border-border-glass hover:border-primary-text hover:text-primary-text'
            } ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Grid */}
      <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence mode="popLayout">
          {isLoading ? (
            // Skeleton Loaders
            Array.from({ length: 3 }).map((_, i) => (
              <motion.div
                key={`skeleton-${i}`}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="bg-card-bg rounded-2xl border border-border-glass overflow-hidden shadow-sm flex flex-col h-full"
              >
                <div className="h-48 w-full bg-secondary-bg animate-pulse" />
                <div className="p-8 flex-grow flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <div className="h-6 w-24 bg-secondary-bg rounded-full animate-pulse" />
                    <div className="h-4 w-16 bg-secondary-bg rounded animate-pulse" />
                  </div>
                  <div className="h-8 w-3/4 bg-secondary-bg rounded mb-4 animate-pulse" />
                  <div className="h-4 w-full bg-secondary-bg rounded mb-2 animate-pulse" />
                  <div className="h-4 w-5/6 bg-secondary-bg rounded mb-8 animate-pulse" />
                  
                  <div className="grid grid-cols-2 gap-4 mb-8 py-6 border-y border-border-glass">
                    <div>
                      <div className="h-8 w-16 bg-secondary-bg rounded mb-2 animate-pulse" />
                      <div className="h-3 w-12 bg-secondary-bg rounded animate-pulse" />
                    </div>
                    <div>
                      <div className="h-8 w-16 bg-secondary-bg rounded mb-2 animate-pulse" />
                      <div className="h-3 w-12 bg-secondary-bg rounded animate-pulse" />
                    </div>
                  </div>
                  
                  <div className="h-5 w-32 bg-secondary-bg rounded mt-auto animate-pulse" />
                </div>
              </motion.div>
            ))
          ) : (
            filteredStudies.map((study) => (
              <motion.div
                key={study.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="bg-card-bg rounded-2xl border border-border-glass overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-[6px] transition-all duration-300 group flex flex-col h-full"
              >
                <div className="relative h-48 w-full overflow-hidden border-b border-border-glass">
                  <Image 
                    src={study.image} 
                    alt={study.title} 
                    fill 
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-primary-bg/10 group-hover:bg-transparent transition-colors duration-500" />
                </div>
                <div className="p-8 flex-grow flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <span className="inline-block px-3 py-1 bg-secondary-bg text-primary-text rounded-full text-xs font-sans font-bold uppercase tracking-[1px]">
                      {study.industry}
                    </span>
                    <span className="text-xs font-sans font-bold uppercase tracking-[1px] text-brand-action">
                      {study.category}
                    </span>
                  </div>
                  
                  <h3 className="font-sans font-bold text-[24px] md:text-[28px] leading-[1.2] text-primary-text mb-4 group-hover:text-brand-action transition-colors">
                    {study.title}
                  </h3>
                  
                  <p className="font-sans text-[15px] leading-[1.7] text-secondary-text mb-8 flex-grow">
                    <strong className="text-primary-text">Challenge:</strong> {study.challenge}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-8 py-6 border-y border-border-glass">
                    {study.metrics.map((metric, i) => (
                      <div key={i}>
                        <p className="font-mono font-bold text-[32px] text-primary-text leading-none mb-1">{metric.value}</p>
                        <p className="font-sans text-[11px] font-bold uppercase tracking-[1px] text-muted-text">{metric.label}</p>
                      </div>
                    ))}
                  </div>
                  
                  <Link 
                    href={`/case-studies/${study.slug}`}
                    className="inline-flex items-center gap-2 font-sans font-medium text-[15px] text-primary-text group-hover:text-brand-action transition-colors uppercase tracking-[1px] mt-auto"
                  >
                    Read Case Study <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </motion.div>
      
      {!isLoading && filteredStudies.length === 0 && (
        <div className="text-center py-20">
          <p className="font-sans text-[18px] text-secondary-text">More case studies in this category coming soon.</p>
        </div>
      )}
    </section>
  );
}
