'use client';

import { motion, useScroll, useTransform } from 'motion/react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import HeroCyclingWord from './HeroCyclingWord';
import MagneticButton from './MagneticButton';
import SplitText from './SplitText';
import dynamic from 'next/dynamic';
import { useRef } from 'react';

const HeroSlider = dynamic(() => import('@/components/HeroSlider'), { ssr: false });

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y     = useTransform(scrollYProgress, [0, 1], ['0%', '25%']);
  const opacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  return (
    <>
      <section ref={ref} className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-[#FAFAF8]">
        <HeroSlider />

        <motion.div
          style={{ y, opacity }}
          className="w-full max-w-[920px] mx-auto px-6 py-[120px] flex flex-col items-center text-center relative z-10"
        >
          {/* Eyebrow tag */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: [0.33, 1, 0.68, 1] }}
            className="mb-8 inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm border border-[#E0DDD6] rounded-full px-5 py-2"
          >
            <motion.span
              animate={{ scale: [1, 1.4, 1], opacity: [1, 0.4, 1] }}
              transition={{ duration: 1.8, repeat: Infinity }}
              className="w-2 h-2 rounded-full bg-[#E8440A] inline-block"
            />
            <span className="font-sans text-[12px] font-bold uppercase tracking-[2px] text-[#4A4A4A]">
              360° Performance Marketing Agency
            </span>
          </motion.div>

          {/* Main headline with SplitText */}
          <h1 className="font-display font-extrabold leading-[1.05] tracking-[-0.03em] text-[#0D0D0D] mb-8"
            style={{ fontSize: 'clamp(40px, 6vw, 72px)' }}>
            <span className="block overflow-hidden">
              <SplitText text="We Don't Just Run Campaigns." delay={0.1} stagger={0.025} />
            </span>
            <span className="block overflow-hidden mt-1">
              <SplitText text="We Build " delay={0.4} stagger={0.025} />
              <HeroCyclingWord />.
            </span>
          </h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.7, ease: [0.33, 1, 0.68, 1] }}
            className="font-sans font-normal text-[18px] md:text-[21px] leading-[1.65] max-w-[620px] mx-auto text-[#4A4A4A]"
          >
            Built for ambitious brands who demand performance across every digital channel — SEO, Paid Ads, Creative, Development, ORM and Influencer.
          </motion.p>

          {/* CTA Buttons with magnetic effect */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.9, ease: [0.33, 1, 0.68, 1] }}
            className="flex flex-col sm:flex-row gap-4 mt-12 w-full sm:w-auto"
          >
            <MagneticButton>
              <Link
                href="/contact"
                className="group font-sans font-semibold text-[15px] tracking-[0.5px] rounded-full flex items-center justify-center gap-2 bg-[#E8440A] hover:bg-[#1B2D5B] text-white px-[36px] py-[17px] shadow-lg shadow-[#E8440A]/25 transition-all duration-300"
              >
                Start Your Growth Journey
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </MagneticButton>

            <MagneticButton>
              <Link
                href="/case-studies"
                className="font-sans font-medium text-[15px] tracking-[0.5px] rounded-full flex items-center justify-center bg-white hover:bg-[#F2EFE9] text-[#0D0D0D] border border-[#E0DDD6] hover:border-[#1B2D5B] px-[36px] py-[17px] transition-all duration-300"
              >
                View Our Work
              </Link>
            </MagneticButton>
          </motion.div>

          {/* Trust line */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 1.1 }}
            className="font-sans font-light text-[13px] mt-6 text-[#888888]"
          >
            No long-term contracts • Free 360° audit • Results in 90 days
          </motion.p>

          {/* Scroll indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="mt-16 flex flex-col items-center gap-2"
          >
            <span className="font-sans text-[11px] uppercase tracking-[2px] text-[#888888]">Scroll</span>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.4, repeat: Infinity, ease: 'easeInOut' }}
              className="w-[1px] h-8 bg-gradient-to-b from-[#888888] to-transparent"
            />
          </motion.div>
        </motion.div>
      </section>

      {/* Stats ticker */}
      <div className="w-full bg-[#1B2D5B] h-[60px] md:h-[72px] overflow-hidden flex items-center relative">
        <div className="flex whitespace-nowrap animate-[marquee_20s_linear_infinite]">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex items-center">
              {[['$6M+','Ad Spend Managed'], ['8.4x','Average ROAS'], ['97%','Client Retention'], ['200+','Campaigns Delivered']].map(([val, label]) => (
                <div key={label} className="flex items-center">
                  <div className="flex items-center px-6 md:px-12">
                    <span className="font-sans font-black text-[20px] md:text-[26px] text-[#E8440A] mr-2 md:mr-3">{val}</span>
                    <span className="font-sans font-light text-[10px] md:text-[12px] uppercase tracking-[2px] text-white/70">{label}</span>
                  </div>
                  <div className="w-px h-6 bg-white/15" />
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
