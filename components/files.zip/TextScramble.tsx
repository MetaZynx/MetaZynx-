'use client';

import { useEffect, useRef, useState } from 'react';
import { useInView } from 'motion/react';

const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&';

interface Props {
  text: string;
  className?: string;
  trigger?: boolean;
  speed?: number;
}

export default function TextScramble({ text, className = '', trigger = true, speed = 40 }: Props) {
  const [displayed, setDisplayed] = useState(text);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const hasRun = useRef(false);

  useEffect(() => {
    if ((!isInView && !trigger) || hasRun.current) return;
    hasRun.current = true;

    let frame = 0;
    const totalFrames = text.length * 3;
    let interval: ReturnType<typeof setInterval>;

    interval = setInterval(() => {
      frame++;
      const progress = frame / totalFrames;
      const revealedCount = Math.floor(progress * text.length);

      setDisplayed(
        text
          .split('')
          .map((char, i) => {
            if (char === ' ') return ' ';
            if (i < revealedCount) return char;
            return CHARS[Math.floor(Math.random() * CHARS.length)];
          })
          .join('')
      );

      if (frame >= totalFrames) {
        setDisplayed(text);
        clearInterval(interval);
      }
    }, speed);

    return () => clearInterval(interval);
  }, [isInView, text, trigger, speed]);

  return (
    <span ref={ref} className={`font-mono ${className}`} aria-label={text}>
      {displayed}
    </span>
  );
}
