'use client';

import { motion } from 'motion/react';

interface Props {
  text: string;
  className?: string;
  delay?: number;
  duration?: number;
  stagger?: number;
  once?: boolean;
}

export default function SplitText({
  text, className = '', delay = 0, duration = 0.6, stagger = 0.04, once = true
}: Props) {
  const words = text.split(' ');

  return (
    <span className={`inline ${className}`} aria-label={text}>
      {words.map((word, wi) => (
        <span key={wi} className="inline-block overflow-hidden mr-[0.25em]">
          {word.split('').map((char, ci) => (
            <motion.span
              key={ci}
              className="inline-block"
              initial={{ y: '100%', opacity: 0 }}
              whileInView={{ y: '0%', opacity: 1 }}
              viewport={{ once }}
              transition={{
                duration,
                delay: delay + (wi * word.length + ci) * stagger,
                ease: [0.33, 1, 0.68, 1],
              }}
            >
              {char}
            </motion.span>
          ))}
        </span>
      ))}
    </span>
  );
}
