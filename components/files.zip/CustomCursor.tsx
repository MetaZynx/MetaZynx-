'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, useMotionValue, useSpring } from 'motion/react';

export default function CustomCursor() {
  const [isVisible, setIsVisible] = useState(false);
  const [cursorType, setCursorType] = useState<'default' | 'hover' | 'click' | 'text'>('default');
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);
  const dotX = useMotionValue(-100);
  const dotY = useMotionValue(-100);

  const springConfig = { stiffness: 150, damping: 18, mass: 0.5 };
  const dotConfig  = { stiffness: 400, damping: 28, mass: 0.2 };

  const springX = useSpring(cursorX, springConfig);
  const springY = useSpring(cursorY, springConfig);
  const dotSX   = useSpring(dotX, dotConfig);
  const dotSY   = useSpring(dotY, dotConfig);

  useEffect(() => {
    // Hide on mobile
    if (window.matchMedia('(hover: none)').matches) return;

    const move = (e: MouseEvent) => {
      cursorX.set(e.clientX - 20);
      cursorY.set(e.clientY - 20);
      dotX.set(e.clientX - 4);
      dotY.set(e.clientY - 4);
      setIsVisible(true);
    };

    const handleEnter = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.matches('a, button, [role="button"], .magnetic')) setCursorType('hover');
      else if (target.matches('p, h1, h2, h3, h4, span, input, textarea')) setCursorType('text');
      else setCursorType('default');
    };

    const handleDown  = () => setCursorType('click');
    const handleUp    = () => setCursorType('default');
    const handleLeave = () => setIsVisible(false);
    const handleEnterWindow = () => setIsVisible(true);

    document.addEventListener('mousemove', move);
    document.addEventListener('mouseover', handleEnter);
    document.addEventListener('mousedown', handleDown);
    document.addEventListener('mouseup', handleUp);
    document.addEventListener('mouseleave', handleLeave);
    document.addEventListener('mouseenter', handleEnterWindow);

    return () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseover', handleEnter);
      document.removeEventListener('mousedown', handleDown);
      document.removeEventListener('mouseup', handleUp);
      document.removeEventListener('mouseleave', handleLeave);
      document.removeEventListener('mouseenter', handleEnterWindow);
    };
  }, [cursorX, cursorY, dotX, dotY]);

  if (typeof window !== 'undefined' && window.matchMedia('(hover: none)').matches) return null;

  const ringSize = cursorType === 'hover' ? 52 : cursorType === 'click' ? 28 : cursorType === 'text' ? 4 : 40;
  const ringBg   = cursorType === 'hover' ? 'rgba(232,68,10,0.12)' : 'transparent';
  const ringBorder = cursorType === 'text' ? 'transparent' : cursorType === 'hover' ? '#E8440A' : 'rgba(27,45,91,0.5)';
  const dotSize  = cursorType === 'text' ? 12 : cursorType === 'click' ? 12 : 8;
  const dotColor = cursorType === 'hover' ? '#E8440A' : '#1B2D5B';

  return (
    <>
      {/* Outer ring */}
      <motion.div
        style={{ x: springX, y: springY, opacity: isVisible ? 1 : 0 }}
        animate={{ width: ringSize, height: ringSize, backgroundColor: ringBg, borderColor: ringBorder }}
        transition={{ duration: 0.2 }}
        className="fixed top-0 left-0 rounded-full border-2 pointer-events-none z-[9999] mix-blend-multiply"
      />
      {/* Inner dot */}
      <motion.div
        style={{ x: dotSX, y: dotSY, opacity: isVisible ? 1 : 0 }}
        animate={{ width: dotSize, height: dotSize, backgroundColor: dotColor }}
        transition={{ duration: 0.15 }}
        className="fixed top-0 left-0 rounded-full pointer-events-none z-[9999]"
      />
    </>
  );
}
