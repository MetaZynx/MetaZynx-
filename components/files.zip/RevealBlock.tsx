'use client';

import { motion } from 'motion/react';
import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
  className?: string;
  once?: boolean;
}

export default function RevealBlock({
  children, delay = 0, direction = 'up', className = '', once = true
}: Props) {
  const dirMap = {
    up:    { y: 60, x: 0 },
    down:  { y: -60, x: 0 },
    left:  { y: 0, x: 60 },
    right: { y: 0, x: -60 },
  };
  const initial = { opacity: 0, ...dirMap[direction] };

  return (
    <motion.div
      initial={initial}
      whileInView={{ opacity: 1, y: 0, x: 0 }}
      viewport={{ once, margin: '-80px' }}
      transition={{ duration: 0.75, delay, ease: [0.33, 1, 0.68, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
